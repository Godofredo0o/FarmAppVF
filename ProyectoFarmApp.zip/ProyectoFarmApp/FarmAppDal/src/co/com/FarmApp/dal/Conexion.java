/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dal;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String DATA_BASE = "farmapp";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private Connection link = null;

    public Connection conectar() throws SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }

        String path = URL + DATA_BASE;
        link = DriverManager.getConnection(path, USER, PASSWORD);
        return this.link;
    }

    public void desconectar() throws SQLException {

        link.close();
    }

}
