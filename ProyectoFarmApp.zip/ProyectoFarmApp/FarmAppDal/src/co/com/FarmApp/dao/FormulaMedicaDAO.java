/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class FormulaMedicaDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public FormulaMedicaDAO() {
        db = new Conexion();
    }

    public FormulaMedica consultaXcodigo(Integer codigo) throws SQLException {

        FormulaMedica formula = new FormulaMedica();

        sql = "SELECT * FROM FormulaMedica WHERE codigo = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigo);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        formula.setCodigo(rs.getInt("codigo"));
        formula.setFecha(rs.getString("fecha"));
        formula.setPosologia(rs.getString("posologia"));
        formula.setPrioridad(rs.getString("prioridad"));

        return formula;
    }

    public Integer borrarXcodigo(FormulaMedica codigo) throws SQLException {

        sql = "DELETE FROM FormulaMedica WHERE codigo = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigo.getCodigo());
        return pstmt.executeUpdate();
    }

    public FormulaMedica insertar(FormulaMedica formulaMedica) throws SQLException {

        sql = "INSERT INTO formulaMedica (coigoUsuario,fecha,posologia,codigoProducto,prioridad)"
                + "VALUES (?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, formulaMedica.getCodigoUsuario().getCodigoUsuario());
        pstmt.setString(2, formulaMedica.getFecha());
        pstmt.setString(3, formulaMedica.getPosologia());
        pstmt.setInt(4, formulaMedica.getCodigoProducto().getCodigoProducto());
        pstmt.setString(5, formulaMedica.getPrioridad());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();

        formulaMedica.setCodigo(rs.getInt(1));

        return formulaMedica;

    }

    public Integer update(FormulaMedica formulaMedica) throws SQLException {
        sql = "UPDATE FormulaMedica SET fecha=?, posologia=? WHERE codigo=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setString(1, formulaMedica.getFecha());
        pstmt.setString(2, formulaMedica.getPosologia());
        pstmt.setInt(3, formulaMedica.getCodigo());
        return pstmt.executeUpdate();
    }
}
