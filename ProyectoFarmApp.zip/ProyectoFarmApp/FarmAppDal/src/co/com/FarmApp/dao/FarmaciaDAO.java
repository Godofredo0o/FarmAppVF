/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class FarmaciaDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public FarmaciaDAO() {
        db = new Conexion();
    }

    public Farmacia consultaXcodigoFarmacia(Integer codigoFarmacia) throws SQLException {

        Farmacia farmacia = new Farmacia();

        sql = "SELECT * FROM Farmacia WHERE codigoFarmacia = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoFarmacia);
        ResultSet rs = pstmt.executeQuery();

        rs.next();

        farmacia.setCodigoFarmacia(rs.getInt("codigoFarmacia"));
        farmacia.setNit(rs.getInt("nit"));
        farmacia.setNombre(rs.getString("nombre"));
        farmacia.setDireccion(rs.getString("direccion"));
        farmacia.setTelefono(rs.getInt("telefono"));
        farmacia.setHorario(rs.getString("horario"));

        return farmacia;
    }

    public Farmacia insertar(Farmacia farmacia) throws SQLException {

        sql = "INSERT INTO farmacia (nit,nombre,direccion,telefono,horario)"
                + "VALUES (?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, farmacia.getNit());
        pstmt.setString(2, farmacia.getNombre());
        pstmt.setString(3, farmacia.getDireccion());
        pstmt.setInt(4, farmacia.getTelefono());
        pstmt.setString(5, farmacia.getHorario());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();

        farmacia.setCodigoFarmacia(rs.getInt(1));

        return farmacia;

    }

    public Integer updateFarmacia(Farmacia farmacia) throws SQLException {

        sql = "UPDATE farmacia SET nombre=?, direccion=?, telefono=?, horario=? WHERE codigoFarmacia=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setString(1, farmacia.getNombre());
        pstmt.setString(2, farmacia.getDireccion());
        pstmt.setInt(3, farmacia.getTelefono());
        pstmt.setString(4, farmacia.getHorario());
        pstmt.setInt(5, farmacia.getCodigoFarmacia());

        return pstmt.executeUpdate();
    }

    public Integer borrarFarmacia(Farmacia f) throws SQLException {

        sql = "DELETE FROM Farmacia WHERE codigoFarmacia = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, f.getCodigoFarmacia());

        return pstmt.executeUpdate();
    }
}
