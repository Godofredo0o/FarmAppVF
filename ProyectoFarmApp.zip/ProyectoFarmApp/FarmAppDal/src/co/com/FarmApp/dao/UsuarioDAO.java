/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class UsuarioDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public UsuarioDAO() {
        db = new Conexion();

    }

    public Usuario consultaXcodigo(Integer codigoUsuario) throws SQLException {

        Usuario usuario = new Usuario();

        sql = "SELECT * FROM Usuario WHERE codigoUsuario =?";
        
            this.pstmt = db.conectar().prepareStatement(sql);
            pstmt.setInt(1, codigoUsuario);

            ResultSet rs = pstmt.executeQuery();
            rs.next();

            usuario.setCodigoUsuario(rs.getInt("codigoUsuario"));
            usuario.setCedula(rs.getLong("cedula"));
            usuario.setNombre(rs.getString("nombre"));
            usuario.setApellido(rs.getString("apellido"));
            usuario.setFechaNacimiento(rs.getString("fechaNacimiento"));
            usuario.setTelefono(rs.getLong("telefono"));
            usuario.setDireccion(rs.getString("direccion"));
            usuario.setEps(rs.getString("eps"));
            usuario.setContactoRespaldo(rs.getString("contactoRespaldo"));
            usuario.setTelefonoRespaldo(rs.getLong("telefonoRespaldo"));
            usuario.setVinculoRespaldo(rs.getString("vinculoRespaldo"));
            
        return usuario;
    }
    
    public Usuario ConsultarXnick(String nick, String clave) throws SQLException {

        Usuario usuario = new Usuario();

        sql = "SELECT nick, clave, tipoCuenta FROM Personas WHERE nick = ?, clave = ?, tipoCuenta = ?";
        
        this.pstmt=db.conectar().prepareStatement(sql);
        pstmt.setString(1, usuario.getNick());
        pstmt.setString(2, usuario.getClave());
        
        ResultSet rs=pstmt.executeQuery();
        
        usuario.setNick(rs.getString("nick"));
        usuario.setClave(rs.getString("clave"));
        usuario.setTipoCuenta(rs.getString("tipoCuenta"));
        
        return usuario;
    }
    
   

    public Integer borrarXUsuario(Usuario codigoUsuario) throws SQLException {

        sql = "DELETE FROM Usuario WHERE codigoUsuario = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoUsuario.getCodigoUsuario());
        return pstmt.executeUpdate();
    }

    public Usuario insertar(Usuario usuario) throws SQLException {

        sql = "INSERT INTO usuario (cedula,nombre,apellido,fechaNacimiento,telefono,direccion,eps,contactoRespaldo,vinculoRespaldo,telefonoRespaldo,nick,clave,tipoCuenta)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setLong(1, usuario.getCedula());
        pstmt.setString(2, usuario.getNombre());
        pstmt.setString(3, usuario.getApellido());
        pstmt.setString(4, usuario.getFechaNacimiento());
        pstmt.setLong(5, usuario.getTelefono());
        pstmt.setString(6, usuario.getDireccion());
        pstmt.setString(7, usuario.getEps());
        pstmt.setString(8, usuario.getContactoRespaldo());
        pstmt.setString(9, usuario.getVinculoRespaldo());
        pstmt.setLong(10, usuario.getTelefonoRespaldo());
        pstmt.setString(11, usuario.getNick());
        pstmt.setString(12, usuario.getClave());
        pstmt.setString(13, usuario.getTipoCuenta());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();
        System.out.println("llave generada" + rs);
        Integer resul = pstmt.getResultSetType();
        System.out.println("resultado rs " + resul);

        usuario.setCodigoUsuario(rs.getInt(1));

        return usuario;
    }

    public Integer updateUsuario(Usuario usuario) throws SQLException {
        sql = "UPDATE Usuario SET cedula=?, nombre=?, apellido=?, fechaNacimiento=?, telefono=?, direccion=?, eps=?, contactoRespaldo=?, telefonoRespaldo=?, vinculoRespaldo=? WHERE codigoUsuario=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setLong(1, usuario.getCedula());
        pstmt.setString(2, usuario.getNombre());
        pstmt.setString(3, usuario.getApellido());
        pstmt.setString(4, usuario.getFechaNacimiento());
        pstmt.setLong(5, usuario.getTelefono());
        pstmt.setString(6, usuario.getDireccion());
        pstmt.setString(7, usuario.getEps());
        pstmt.setString(8, usuario.getContactoRespaldo());
        pstmt.setLong(9, usuario.getTelefonoRespaldo());
        pstmt.setString(10, usuario.getVinculoRespaldo());
        pstmt.setInt(11, usuario.getCodigoUsuario());
        
        return pstmt.executeUpdate();
    }
}
