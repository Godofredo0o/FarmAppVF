/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class MedicamentoDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public MedicamentoDAO() {
        db = new Conexion();
    }

    public Medicamento insertar(Medicamento medicamento) throws SQLException {

        sql = "INSERT INTO medicamento (codigoBarras,nombre,tipo,descripcionProducto,valor,cantidadDisponible)"
                + "VALUES (?,?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, medicamento.getCodigoProducto());
        pstmt.setInt(2, medicamento.getCodigoBarras());
        pstmt.setString(3, medicamento.getNombre());
        pstmt.setString(4, medicamento.getTipo());
        pstmt.setString(5, medicamento.getDescripcionProducto());
        pstmt.setDouble(6, medicamento.getValor());
        pstmt.setFloat(7, medicamento.getCantidadDisponible());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();

        medicamento.setCodigoProducto(rs.getInt(1));

        return medicamento;
    }

    public Integer update(Medicamento medicamento) throws SQLException {
        sql = "UPDATE medicamento SET codigoBarras=?,nombre=?,tipo=?,descripcionProducto=?,valor=? WHERE codigoProducto=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, medicamento.getCodigoBarras());
        pstmt.setString(2, medicamento.getNombre());
        pstmt.setString(3, medicamento.getTipo());
        pstmt.setString(4, medicamento.getDescripcionProducto());
        pstmt.setDouble(5, medicamento.getValor());
        pstmt.setInt(6, medicamento.getCodigoProducto());
        return pstmt.executeUpdate();
    }

    public Medicamento buscarXcodigoProducto(Integer codigoProducto) throws SQLException {

        Medicamento medicamento = new Medicamento();

        sql = "SELECT * FROM medicamento WHERE codigoProducto = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoProducto);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        medicamento.setCodigoProducto(rs.getInt("codigoProducto"));
        medicamento.setCodigoBarras(rs.getInt("codigoBarras"));
        medicamento.setNombre(rs.getString("nombre"));
        medicamento.setTipo(rs.getString("tipo"));
        medicamento.setDescripcionProducto(rs.getString("descripcionProducto"));
        medicamento.setValor(rs.getDouble("valor"));
        medicamento.setCantidadDisponible(rs.getInt("cantidadDisponible"));

        return medicamento;
    }

    public Integer borrarMedicamento(Medicamento m) throws SQLException {

        sql = "DELETE FROM medicamento WHERE codigoProducto = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, m.getCodigoProducto());
        return pstmt.executeUpdate();
    }
}
