/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class DespachoDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public DespachoDAO() {

        db = new Conexion();

    }

    public Despacho insertar(Despacho despacho) throws SQLException {

        sql = "INSERT INTO despacho (cantidad,pedido_codigoPedido)"
                + "VALUES (?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, despacho.getCantidad());
        pstmt.setInt(2, despacho.getPedido().getCodigoPedido());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();

        despacho.setCodigoDespacho(rs.getInt(1));

        return despacho;
    }

    public Integer update(Despacho despacho) throws SQLException {

        sql = "UPDATE despacho SET cantidad=? WHERE codigoDespacho = ?;";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, despacho.getCantidad());
        pstmt.setInt(2, despacho.getCodigoDespacho());

        return pstmt.executeUpdate();
    }

    public Despacho consultaXcodigoDespacho(Integer codigoDespacho) throws SQLException {

        Despacho despacho = new Despacho();
        Pedido pedido = new Pedido();
        PedidoDAO pedidodao = new PedidoDAO();

        sql = "SELECT * FROM despacho WHERE codigoDespacho = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoDespacho);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        despacho.setCodigoDespacho(rs.getInt("codigoDespacho"));
        despacho.setCantidad(rs.getInt("cantidad"));
        pedido = pedidodao.buscarXcodigoPedido(rs.getInt("pedido"));
        despacho.setPedido(pedido);

        return despacho;
    }

    public Integer borrarXdespacho(Despacho codigoDespacho) throws SQLException {

        sql = "DELETE FROM despacho WHERE codigoDespacho = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoDespacho.getCodigoDespacho());

        return pstmt.executeUpdate();
    }
}
