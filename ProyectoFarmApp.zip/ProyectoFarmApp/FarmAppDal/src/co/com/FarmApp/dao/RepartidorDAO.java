/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class RepartidorDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public RepartidorDAO() {
        db = new Conexion();

    }

    public Repartidor insertar(Repartidor repartidor) throws SQLException {

        sql = "INSERT INTO repartidor (cedula,nombre,apellido,licencia,fechaNacimiento,telefono,turnoRepartidor,vehiculo,farmacia_nit,nick,clave,tipoCuenta)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setLong(1, repartidor.getCedula());
        pstmt.setString(2, repartidor.getNombre());
        pstmt.setString(3, repartidor.getApellido());
        pstmt.setString(4, repartidor.getLicencia());
        pstmt.setString(5, repartidor.getFechaNacimiento());
        pstmt.setLong(6, repartidor.getTelefono());
        pstmt.setString(7, repartidor.getTurnoRepartidor());
        pstmt.setString(8, repartidor.getVehiculo());
        pstmt.setInt(9, repartidor.getFarmacia().getNit());
        pstmt.setString(10, repartidor.getNick());
        pstmt.setString(11, repartidor.getClave());
        pstmt.setString(12, repartidor.getTipoCuenta());

        pstmt.execute();
        ResultSet rs = pstmt.executeQuery();
        rs.next();

        repartidor.setCodigoEmpleado(rs.getInt(1));

        return repartidor;
    }

    public Integer update(Repartidor repartidor) throws SQLException {
        sql = "UPDATE Repartidor SET nombre=?, apellido=?, licencia=?, fechaNacimiento=?,telefono=?,turnoRepartidor=?, vehiculo=? WHERE codigoEmpleado=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setString(1, repartidor.getNombre());
        pstmt.setString(2, repartidor.getApellido());
        pstmt.setString(3, repartidor.getLicencia());
        pstmt.setString(4, repartidor.getFechaNacimiento());
        pstmt.setLong(5, repartidor.getTelefono());
        pstmt.setString(6, repartidor.getTurnoRepartidor());
        pstmt.setString(7, repartidor.getVehiculo());
        pstmt.setInt(8, repartidor.getCodigoEmpleado());

        return pstmt.executeUpdate();
    }

    public Repartidor buscarXcodigoEmpleado(Integer codigoEmpleado) throws SQLException {

        Repartidor repartidor = new Repartidor();
        Farmacia farmacia = new Farmacia();
        FarmaciaDAO farmaciadao = new FarmaciaDAO();

        sql = "SELECT * FROM Repartidor WHERE codigoEmpleado = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoEmpleado);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        repartidor.setCodigoEmpleado(rs.getInt("codigoEmpleado"));
        repartidor.setCedula(rs.getLong("cedula"));
        repartidor.setNombre(rs.getString("nombre"));
        repartidor.setApellido(rs.getString("apellido"));
        repartidor.setLicencia(rs.getString("licencia"));
        repartidor.setFechaNacimiento(rs.getString("fechaNacimiento"));
        repartidor.setTelefono(rs.getLong("telefono"));
        repartidor.setTurnoRepartidor(rs.getString("turnoRepartidor"));
        repartidor.setVehiculo(rs.getString("vehiculo"));
        farmacia = farmaciadao.consultaXcodigoFarmacia(rs.getInt("farmacia"));
        repartidor.setFarmacia(farmacia);

        return repartidor;
    }

    public Integer borrarRepartidor(Repartidor r) throws SQLException {

        sql = "DELETE FROM repartidor WHERE codigoEmpleado = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, r.getCodigoEmpleado());

        return pstmt.executeUpdate();
    }
}
