/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class OrdenEntregaDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public OrdenEntregaDAO() {
        db = new Conexion();

    }

    public OrdenEntrega insertar(OrdenEntrega ordenEntrega) throws SQLException {

        sql = "INSERT INTO ordenEntrega (repartidor_codigoEmpleado,factura_codigo)"
                + "VALUES (?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, ordenEntrega.getRepartidor().getCodigoEmpleado());
        pstmt.setFloat(2, ordenEntrega.getFactura().getCodigo());

        pstmt.execute();
        ResultSet rs = pstmt.executeQuery();
        rs.next();

        ordenEntrega.setCodigoEntrega(rs.getInt(1));

        return ordenEntrega;

    }

    public Integer update(OrdenEntrega ordenEntrega) throws SQLException {
        sql = "UPDATE ordenEntrega SET repartidor=? WHERE codigoEntrega=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, ordenEntrega.getRepartidor().getCodigoEmpleado());
        pstmt.setInt(2, ordenEntrega.getCodigoEntrega());

        return pstmt.executeUpdate();
    }

    public OrdenEntrega buscarXcodigoEntrega(Integer codigoEntrega) throws SQLException {

        OrdenEntrega orden = new OrdenEntrega();
        Factura factura = new Factura();
        FacturaDAO facturadao = new FacturaDAO();
        Repartidor repartidor = new Repartidor();
        RepartidorDAO repartidordao = new RepartidorDAO();

        sql = "SELECT *FROM ordenEntrega WHERE codigoEntrega = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoEntrega);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        orden.setCodigoEntrega(rs.getInt("codigoEntrega"));
        repartidor = repartidordao.buscarXcodigoEmpleado(rs.getInt("codigoEmpleado"));
        orden.setRepartidor(repartidor);
        factura = facturadao.buscarXcodigoFactura(rs.getInt("codigo"));
        orden.setFactura(factura);

        return orden;
    }

    public Integer borrarEntrega(OrdenEntrega o) throws SQLException {

        sql = "DELETE FROM ordenEntrega WHERE codigoEntrega = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, o.getCodigoEntrega());

        return pstmt.executeUpdate();
    }

}
