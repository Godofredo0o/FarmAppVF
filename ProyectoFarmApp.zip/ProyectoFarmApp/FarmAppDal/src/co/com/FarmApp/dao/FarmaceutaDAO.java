/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class FarmaceutaDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public FarmaceutaDAO() {
        db = new Conexion();

    }

    public Farmaceuta consultaXcodigo(Integer CodigoEmpleado) throws SQLException {

        Farmaceuta farmaceuta = new Farmaceuta();
        Farmacia farmacia = new Farmacia();
        FarmaciaDAO fDao = new FarmaciaDAO();

        sql = "SELECT * FROM Farmaceuta WHERE codigoEmpleado = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, CodigoEmpleado);

        ResultSet rs = pstmt.executeQuery();

        rs.next();

        farmaceuta.setCodigoEmpleado(rs.getInt("codigoEmpleado"));
        farmaceuta.setCedula(rs.getLong("cedula"));
        farmaceuta.setNombre(rs.getString("nombre"));
        farmaceuta.setApellido(rs.getString("apellido"));
        farmaceuta.setFechaNacimiento(rs.getString("fechaNacimiento"));
        farmaceuta.setTelefono(rs.getLong("telefono"));
        farmaceuta.setTurnoFarmaceuta(rs.getString("turnoFarmaceuta"));
        farmaceuta.setTarjetaProfesional(rs.getString("tarjetaProfesional"));

        farmacia = fDao.consultaXcodigoFarmacia(rs.getInt("farmacia"));

        farmaceuta.setFarmacia(farmacia);

        return farmaceuta;
    }

    public Farmaceuta insertar(Farmaceuta farmaceuta) throws SQLException {

        sql = "INSERT INTO farmaceuta (cedula,nombre,apellido,fehaNacimiento,telefono,turnoFarmaceuta,tarjetaProfesional,farmacia_nit,nick,clave,tipoCenta)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setLong(1, farmaceuta.getCedula());
        pstmt.setString(2, farmaceuta.getNombre());
        pstmt.setString(3, farmaceuta.getApellido());
        pstmt.setString(4, farmaceuta.getFechaNacimiento());
        pstmt.setLong(5, farmaceuta.getTelefono());
        pstmt.setString(6, farmaceuta.getTurnoFarmaceuta());
        pstmt.setString(7, farmaceuta.getTarjetaProfesional());
        pstmt.setInt(8, farmaceuta.getFarmacia().getNit());
        pstmt.setString(9, farmaceuta.getNick());
        pstmt.setString(10, farmaceuta.getClave());
        pstmt.setString(11, farmaceuta.getTipoCuenta());

        pstmt.execute();
        ResultSet rs = pstmt.executeQuery();
        rs.next();

        farmaceuta.setCodigoEmpleado(rs.getInt(1));

        return farmaceuta;
    }

    public Integer updateFarmaceuta(Farmaceuta farmaceuta) throws SQLException {

        sql = "UPDATE Farmaceuta SET nombre=?,apellido=?, fechaNacimiento=?,telefono=?, turnoFarmaceuta=?, tarjetaProfesional=? WHERE codigoEmpleado=? ";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setString(1, farmaceuta.getNombre());
        pstmt.setString(2, farmaceuta.getApellido());
        pstmt.setString(3, farmaceuta.getFechaNacimiento());
        pstmt.setLong(4, farmaceuta.getTelefono());
        pstmt.setString(5, farmaceuta.getTurnoFarmaceuta());
        pstmt.setString(6, farmaceuta.getTarjetaProfesional());
        pstmt.setInt(7, farmaceuta.getCodigoEmpleado());

        return pstmt.executeUpdate();
    }

    public Integer borrarFarmaceuta(Farmaceuta f) throws SQLException {

        sql = "DELETE FROM Farmaceuta WHERE codigoEmpleado = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, f.getCodigoEmpleado());

        return pstmt.executeUpdate();
    }
}
