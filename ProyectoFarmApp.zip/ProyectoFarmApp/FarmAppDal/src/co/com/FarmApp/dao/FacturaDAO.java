/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class FacturaDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public FacturaDAO() {
        db = new Conexion();

    }

    public Factura insertar(Factura factura) throws SQLException {

        Despacho despacho = new Despacho();

        sql = "INSERT INTO factura (fechaFactura,costoTotal,despacho_codigoDespacho)"
                + "VALUES (?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setString(1, factura.getFechaFactura());
        pstmt.setDouble(2, factura.getCostoTotal());
        pstmt.setFloat(3, factura.getDespacho().getCodigoDespacho());

        pstmt.execute();
        ResultSet rs = pstmt.getGeneratedKeys();
        rs.next();

        factura.setCodigo(rs.getInt(1));

        return factura;

    }

    public Integer update(Factura factura) throws SQLException {

        sql = "UPDATE factura SET fechaFactura= ?, costoTotal= ? WHERE codigo=? ";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setString(1, factura.getFechaFactura());
        pstmt.setDouble(2, factura.getCostoTotal());
        pstmt.setFloat(3, factura.getCodigo());

        return pstmt.executeUpdate();
    }

    public Factura buscarXcodigoFactura(Integer codigo) throws SQLException {

        Factura factura = new Factura();
        Despacho despacho = new Despacho();
        DespachoDAO despachodao = new DespachoDAO();

        sql = "SELECT * FROM factura WHERE codigo = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigo);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        factura.setCodigo(rs.getInt("codigo"));
        factura.setFechaFactura(rs.getString("fechaFactura"));
        factura.setCostoTotal(rs.getDouble("costoTotal"));
        despacho = despachodao.consultaXcodigoDespacho(rs.getInt("despacho"));
        factura.setDespacho(despacho);

        return factura;
    }

    public Integer borrarXfactura(Factura codigo) throws SQLException {

        sql = "DELETE FROM factura WHERE codigo = ?";
        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigo.getCodigo());

        return pstmt.executeUpdate();
    }

}
