/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.dao;

import java.sql.*;
import co.com.FarmApp.dal.*;
import co.com.FarmApp.ent.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class PedidoDAO {

    private Conexion db;
    private Connection con;
    private String sql;
    private PreparedStatement pstmt;

    public PedidoDAO() {
        db = new Conexion();

    }

    public Pedido insertar(Pedido pedido) throws SQLException {

        sql = "INSERT INTO pedido (usuario_cedula,cantidadSolicitada,medioPago)"
                + "VALUES (?,?,?,?,?)";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setInt(1, pedido.getCodigoProducto().getCodigoProducto());
        pstmt.setLong(2, pedido.getUsuario().getCedula());
        pstmt.setInt(3, pedido.getCantidadSolicitada());
        pstmt.setString(4, pedido.getMedioPago());
        pstmt.setString(5, pedido.getEstado());

        pstmt.executeUpdate();
        ResultSet rs = pstmt.executeQuery();
        rs.next();

        pedido.setCodigoPedido(rs.getInt(1));

        return pedido;
    }

    public Pedido buscarXcodigoPedido(Integer codigoPedido) throws SQLException {
        Pedido pedido = new Pedido();
        Usuario usuario = new Usuario();
        UsuarioDAO usuariodao = new UsuarioDAO();
        Medicamento medicamento = new Medicamento();
        MedicamentoDAO medao = new MedicamentoDAO();

        sql = "SELECT * FROM pedido WHERE codigoPedido = ?";

        this.pstmt = db.conectar().prepareStatement(sql);
        pstmt.setInt(1, codigoPedido);

        ResultSet rs = pstmt.executeQuery();
        rs.next();

        pedido.setCodigoPedido(rs.getInt("codigoPedido"));
        medicamento = medao.buscarXcodigoProducto(rs.getInt("codigoProducto"));
        pedido.setCodigoProducto(medicamento);
        usuario = usuariodao.consultaXcodigo(rs.getInt("usuario"));
        pedido.setUsuario(usuario);
        pedido.setCantidadSolitario(rs.getInt("cantidadSolicitada"));
        pedido.setMedioPago(rs.getString("medioPago"));
        pedido.setEstado(rs.getString("estado"));

        return pedido;
    }

    public Integer update(Pedido pedido) throws SQLException {
        sql = "UPDATE pedido SET cantidadsolicitada=? WHERE codigoPedido=?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, pedido.getCantidadSolicitada());
        pstmt.setInt(2, pedido.getCodigoPedido());
        return pstmt.executeUpdate();
    }

    public Integer borrarPedido(Pedido p) throws SQLException {

        sql = "DELETE FROM pedido WHERE codigoPedido = ?";

        Connection cn = db.conectar();
        pstmt = cn.prepareStatement(sql);

        pstmt.setInt(1, p.getCodigoPedido());

        return pstmt.executeUpdate();
    }
}
