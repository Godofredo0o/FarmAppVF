/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.Bl;

import co.com.FarmApp.dao.*;
import co.com.FarmApp.ent.*;
import java.sql.*;
import java.util.Scanner;
import java.util.logging.*;

/**
 *
 * @author Tecnologia
 */
public class LoginBl {

    Persona persona = new Persona();
    UsuarioDAO usuariodao = new UsuarioDAO();

    public boolean validarUsuario(String nick, String clave, String tipoCuenta) throws SQLException {

        if (usuariodao.ConsultarXnick(nick, clave).getNick().equals(persona.getNick()) && usuariodao.ConsultarXnick(nick, clave).getClave().equals(persona.getClave()) ) {
            
                return true;
        }
        return false;
    }
}
