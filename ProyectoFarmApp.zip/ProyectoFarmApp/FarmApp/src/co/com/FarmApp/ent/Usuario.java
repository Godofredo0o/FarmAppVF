/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Usuario extends Persona {

    private Integer codigoUsuario;
    private String direccion;
    private String eps;
    private String contactoRespaldo;
    private Long telefonoRespaldo;
    private String vinculoRespaldo;
    private FormulaMedica formulaMedica;

    public Integer getCodigoUsuario() {
        return this.codigoUsuario;
    }

    public void setCodigoUsuario(Integer nCodigoUsuario) {
        this.codigoUsuario = nCodigoUsuario;
    }

    public String getDireccion() {
        return this.direccion;
    }

    public void setDireccion(String nDireccion) {
        this.direccion = nDireccion;
    }

    public String getEps() {
        return this.eps;
    }

    public void setEps(String nEps) {
        this.eps = nEps;
    }

    public String getContactoRespaldo() {
        return this.contactoRespaldo;
    }

    public void setContactoRespaldo(String nContactoRespaldo) {
        this.contactoRespaldo = nContactoRespaldo;
    }

    public Long getTelefonoRespaldo() {
        return this.telefonoRespaldo;
    }

    public void setTelefonoRespaldo(Long nTelefonoRespaldo) {
        this.telefonoRespaldo = nTelefonoRespaldo;
    }

    public String getVinculoRespaldo() {
        return this.vinculoRespaldo;
    }

    public void setVinculoRespaldo(String nVinculoRespaldo) {
        this.vinculoRespaldo = nVinculoRespaldo;
    }

    public FormulaMedica getFormulaMedica() {
        return this.formulaMedica;
    }

    public void setFormulaMedica(FormulaMedica nFormulaMedica) {
        this.formulaMedica = nFormulaMedica;
    }
}
