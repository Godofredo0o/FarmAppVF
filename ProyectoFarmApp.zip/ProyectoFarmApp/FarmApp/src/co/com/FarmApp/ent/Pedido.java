/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Pedido {

    private Integer cantidadSolicitada;
    private Usuario usuario;
    private Integer codigoPedido;
    private Medicamento codigoProducto;
    private String medioPago;
    private String estado;

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }

    public Integer getCantidadSolicitada() {
        return this.cantidadSolicitada;
    }

    public void setCantidadSolitario(Integer ncantidadSolicitada) {
        this.cantidadSolicitada = ncantidadSolicitada;
    }

    public Usuario getUsuario() {
        return this.usuario;
    }

    public void setUsuario(Usuario nUsuario) {
        this.usuario = nUsuario;
    }

    public Integer getCodigoPedido() {
        return this.codigoPedido;
    }

    public void setCodigoPedido(Integer nCodigoPedido) {
        this.codigoPedido = nCodigoPedido;
    }
    
    public String getEstado(){
        return this.estado;
    }
    public void setEstado(String nEstado){
        this.estado = nEstado;
    }
    public Medicamento getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(Medicamento nCodigoProducto) {
        this.codigoProducto = nCodigoProducto;
    }
}
