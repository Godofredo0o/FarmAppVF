/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class FormulaMedica {

    private Integer codigo;
    private Usuario codigoUsuario;
    private String fecha;
    private String posologia;
    private Medicamento codigoProducto;
    private String Prioridad;

    public Integer getCodigo() {
        return this.codigo;
    }

    public void setCodigo(Integer nCodigo) {
        this.codigo = nCodigo;
    }

    public Usuario getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(Usuario codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public String getFecha() {
        return this.fecha;
    }

    public void setFecha(String nFecha) {
        this.fecha = nFecha;
    }

    public String getPosologia() {
        return this.posologia;
    }

    public void setPosologia(String nPosologia) {
        this.posologia = nPosologia;
    }

    public String getPrioridad() {
        return this.Prioridad;
    }

    public void setPrioridad(String nPrioridad) {
        this.Prioridad = nPrioridad;
    }

    public Medicamento getCodigoProducto() {
        return this.codigoProducto;
    }

    public void setCodigoProducto(Medicamento nCodigoProducto) {
        this.codigoProducto = nCodigoProducto;
    }
}
