/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Farmaceuta extends Empleado{

    private String tarjetaProfesional;
    private String turnoFarmaceuta;

    public String getTarjetaProfesional() {
        return this.tarjetaProfesional;
    }

    public void setTarjetaProfesional(String ntarjetaProfesional) {
        this.tarjetaProfesional = ntarjetaProfesional;
    }

    public String getTurnoFarmaceuta() {
        return this.turnoFarmaceuta;
    }

    public void setTurnoFarmaceuta(String nTurnoFarmaceuta) {
        this.turnoFarmaceuta = nTurnoFarmaceuta;
    }
}
