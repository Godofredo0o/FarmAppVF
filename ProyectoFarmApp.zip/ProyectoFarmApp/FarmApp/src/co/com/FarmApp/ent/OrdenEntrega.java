/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class OrdenEntrega {

    private Factura factura;
    private Integer codigoEntrega;
    private Repartidor repartidor;

    public Factura getFactura() {
        return this.factura;
    }

    public void setFactura(Factura nFactura) {
        this.factura = nFactura;
    }

    public Repartidor getRepartidor() {
        return this.repartidor;
    }

    public void setRepartidor(Repartidor nRepartidor) {
        this.repartidor = nRepartidor;
    }

    public Integer getCodigoEntrega() {
        return this.codigoEntrega;
    }

    public void setCodigoEntrega(Integer ncodigoEntrega) {
        this.codigoEntrega = ncodigoEntrega;
    }

}
