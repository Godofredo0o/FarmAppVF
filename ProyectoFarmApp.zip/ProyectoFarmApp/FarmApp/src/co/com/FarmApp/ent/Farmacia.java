/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Farmacia {

    private Integer codigoFarmacia;
    private Integer nit;
    private String nombre;
    private String direccion;
    private Integer telefono;
    private String horario;

    public Integer getCodigoFarmacia() {
        return this.codigoFarmacia;
    }

    public void setCodigoFarmacia(Integer nCodigoFarmacia) {
        this.codigoFarmacia = nCodigoFarmacia;
    }

    public Integer getNit() {
        return this.nit;
    }

    public void setNit(Integer nNit) {
        this.nit = nNit;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nNombre) {
        this.nombre = nNombre;
    }

    public String getDireccion() {
        return this.direccion;
    }

    public void setDireccion(String nDireccion) {
        this.direccion = nDireccion;
    }

    public Integer getTelefono() {
        return this.telefono;
    }

    public void setTelefono(Integer nTelefono) {
        this.telefono = nTelefono;
    }

    public String getHorario() {
        return this.horario;
    }

    public void setHorario(String nHorario) {
        this.horario = nHorario;
    }
}
