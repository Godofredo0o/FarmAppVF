/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Persona {

    private Long cedula;
    private String nombre;
    private String apellido;
    private String fechaNacimiento;
    private Long telefono;
    private String nick;
    private String clave;
    private String tipoCuenta;

    public Long getCedula() {
        return this.cedula;
    }

    public void setCedula(Long nCedula) {
        this.cedula = nCedula;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nNombre) {
        this.nombre = nNombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public void setApellido(String nApellido) {
        this.apellido = nApellido;
    }

    public String getFechaNacimiento() {
        return this.fechaNacimiento;
    }

    public void setFechaNacimiento(String nFechaNacimiento) {
        this.fechaNacimiento = nFechaNacimiento;
    }

    public Long getTelefono() {
        return this.telefono;
    }

    public void setTelefono(Long nTelefono) {
        this.telefono = nTelefono;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCunta) {
        this.tipoCuenta = tipoCunta;
    }
}
