/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Empleado extends Persona{

    private Integer codigoEmpleado;
    private Farmacia farmacia;

    public Integer getCodigoEmpleado(){
        return this.codigoEmpleado;
    }
    public void setCodigoEmpleado(Integer ncodigoEmpleado){
        this.codigoEmpleado=ncodigoEmpleado;
    }
    
    public Farmacia getFarmacia(){
        return this.farmacia;
    }
    public void setFarmacia(Farmacia nfarmacia){
        this.farmacia=nfarmacia;
    }
}
