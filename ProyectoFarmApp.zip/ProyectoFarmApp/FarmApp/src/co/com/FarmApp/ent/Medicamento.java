/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Medicamento {

    private String nombre;
    private Integer codigoProducto;
    private Integer codigoBarras;
    private String tipo;
    private String descripcionProducto;
    private Double valor;
    private Integer cantidadDisponible;

    public Integer getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(Integer cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nNombre) {
        this.nombre = nNombre;
    }

    public Integer getCodigoProducto() {
        return this.codigoProducto;
    }

    public void setCodigoProducto(Integer nCodigoProducto) {
        this.codigoProducto = nCodigoProducto;
    }

    public Integer getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(Integer codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String nTipo) {
        this.tipo = nTipo;
    }

    public String getDescripcionProducto() {
        return this.descripcionProducto;
    }

    public void setDescripcionProducto(String nDescripcionProducto) {
        this.descripcionProducto = nDescripcionProducto;
    }

    public Double getValor() {
        return this.valor;
    }

    public void setValor(Double nValor) {
        this.valor = nValor;
    }

}
