/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Despacho {

    private Integer codigoDespacho;
    private Integer cantidad;
    private Pedido pedido;

    public Integer getCodigoDespacho() {
        return this.codigoDespacho;
    }

    public void setCodigoDespacho(Integer nCodigodespacho) {
        this.codigoDespacho = nCodigodespacho;
    }

    public Integer getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(Integer nCantidad) {
        this.cantidad = nCantidad;
    }

    public Pedido getPedido() {
        return this.pedido;
    }

    public void setPedido(Pedido npedido) {
        this.pedido = npedido;
    }

}
