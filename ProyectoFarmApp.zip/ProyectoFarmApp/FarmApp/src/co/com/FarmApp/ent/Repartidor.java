/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.ent;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class Repartidor extends Empleado {

    private String licencia;
    private String Vehiculo;
    private String turnoRepartidor;

    public String getLicencia() {
        return this.licencia;
    }

    public void setLicencia(String nLicencia) {
        this.licencia = nLicencia;
    }

    public String getVehiculo() {
        return this.Vehiculo;
    }

    public void setVehiculo(String nVehiculo) {
        this.Vehiculo = nVehiculo;
    }

    public String getTurnoRepartidor() {
        return this.turnoRepartidor;
    }

    public void setTurnoRepartidor(String nTurnoRepartidor) {
        this.turnoRepartidor = nTurnoRepartidor;
    }

}
