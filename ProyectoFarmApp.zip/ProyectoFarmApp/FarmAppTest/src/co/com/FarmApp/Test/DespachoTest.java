/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.Test;

import co.com.FarmApp.dao.*;
import co.com.FarmApp.ent.*;
import java.sql.*;
import java.util.logging.*;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class DespachoTest {

    private DespachoDAO dd;
    private Despacho d;

    public void insertarDespacho()  {
        
        
        dd = new DespachoDAO();
        d = new Despacho();

        d.setCantidad(14);
        d.setPedido(null);

        try {
            dd.insertar(d);
            
        } catch (SQLException ex) {
            Logger.getLogger(DespachoTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actualizarDespacho() {

        try {
            DespachoDAO despachoD = new DespachoDAO();
            Despacho despachoE = new Despacho();

            despachoE.setCantidad(100);

            despachoE = despachoD.insertar(despachoE);

            if (despachoE.getCodigoDespacho() == null) {

                System.out.println("Codigo de desacho no encontrado");

            } else {
                System.out.println("Cantidad de despacho creada: " + despachoE.getCantidad());
            }

        } catch (Exception e) {
            Logger.getLogger(DespachoTest.class.getName()).log(Level.SEVERE, null, e);
        }
    }

}
