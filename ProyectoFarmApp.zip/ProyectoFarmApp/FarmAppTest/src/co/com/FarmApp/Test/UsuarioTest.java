/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.Test;

import co.com.FarmApp.dao.*;
import co.com.FarmApp.ent.*;
import java.sql.*;
import java.util.Scanner;
import java.util.logging.*;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class UsuarioTest {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        String sel;
        int sel1;

        UsuarioDAO usuariodao;
        Usuario usuario;
        usuario = new Usuario();
        usuariodao = new UsuarioDAO();
        System.out.println("ingrese el codigo del usuario: ");
        sel1 = in.nextInt();
        Integer codigoUsuario = sel1;

        try {
            usuario = usuariodao.consultaXcodigo(codigoUsuario);

            System.out.println("Codigo: " + usuario.getCodigoUsuario());
            System.out.println("Cedula: " + usuario.getCedula());
            System.out.println("Nombre: " + usuario.getNombre());
            System.out.println("apellido: " + usuario.getApellido());
            System.out.println("telefono: " + usuario.getTelefono());
            System.out.println("direccion: " + usuario.getDireccion());
            System.out.println("eps: " + usuario.getEps());
            System.out.println("contactorespaldo: " + usuario.getContactoRespaldo());
            System.out.println("telefonoRespaldo: " + usuario.getTelefonoRespaldo());
            System.out.println("vinculoRespaldo: " + usuario.getVinculoRespaldo());

        } catch (SQLException ex) {
            Logger.getLogger(UsuarioTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //-----------------------------------------------------------------------------------
        usuario.setCodigoUsuario(1);
        System.out.println("esta seguro de que desea borrar? ");
        sel = in.next();

        if (sel.equals("y")) {
            try {
                if (usuariodao.borrarXUsuario(usuario).equals(1)) {
                    System.out.println("Los datos se borraron Exitosamente");
                }
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioTest.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            System.out.println("No se borro ningun dato");
        }
        //-----------------------------------------------------------------------------------

        System.out.println("ingrese el codigo de usuario que desea modificar: ");
        Integer cod = in.nextInt();
        usuario.setCodigoUsuario(cod);

        usuario.setApellido("Mejia");
        usuario.setCedula(151417l);
        usuario.setClave("Mejia1234");
        usuario.setFechaNacimiento("1996-01-01");
        usuario.setDireccion("cra 104n79 a06");
        usuario.setNick("farmaco123");
        usuario.setNombre("Felipin");
        usuario.setTelefono(57894694l);
        usuario.setContactoRespaldo("Hector");
        usuario.setEps("Coomeva");
        usuario.setTelefonoRespaldo(54301169L);
        usuario.setVinculoRespaldo("Padre");

        try {
            usuariodao.updateUsuario(usuario);

            if (usuariodao.updateUsuario(usuario).equals(1)) {
                System.out.println("se modificaron los registros exitosamente");
            } else {
                System.out.println("no update");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioTest.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error" + ex);
        }
//-----------------------------------------------------------------------------------------
        System.out.println("desea agregar usuario ?");
        sel = in.next();

        if (sel.equals("y")) {
            usuario.setCedula(1010238059l);
            usuario.setNombre("Luis");
            usuario.setApellido("Salgado");
            usuario.setFechaNacimiento("1988-02-17");
            usuario.setTelefono(3182350999l);
            usuario.setEps("Sanitas");
            usuario.setDireccion("Cra 9 # 11-43");
            usuario.setContactoRespaldo("Gloria Mendigaña");
            usuario.setTelefonoRespaldo(3044488198l);
            usuario.setVinculoRespaldo("Madre");
            usuario.setNick("luis");
            usuario.setClave("salgado123");
            usuario.setTipoCuenta("U");

            try {
                usuariodao.insertar(usuario);
                System.out.println("usuario creado correctamente");
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioTest.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error al crear el usuario: " + ex);
            }
        } else {    

            System.out.println("Gracias");
        }
    }

}
