/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.Test;

import co.com.FarmApp.dao.*;
import co.com.FarmApp.ent.*;
import java.sql.*;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class FacturaTest {

    FacturaDAO facturaD;
    Factura facturaE;

    public boolean actualizarFactura() throws SQLException {
        facturaD = new FacturaDAO();
        facturaE = new Factura();

        facturaE.setCostoTotal(100.0);
        facturaE.setFechaFactura("1998/10/15");

        facturaE = facturaD.insertar(facturaE);
        if (facturaE.getCodigo() == null) {
            return false;
        } else {
            System.out.println("Costo total: " + facturaE.getCostoTotal());
            System.out.println("Fecha de la factura: " + facturaE.getFechaFactura());
            return true;
        }
    }
}
