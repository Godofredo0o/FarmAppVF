/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.FarmApp.Test;

import co.com.FarmApp.dao.*;
import co.com.FarmApp.ent.*;
import java.sql.*;
import java.util.logging.*;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class FarmaceutaTest {

    FarmaceutaDAO farmaceutaD;
    Farmaceuta farmaceutaE;

    public void actualizarFaramaceuta() {

        try {
            farmaceutaD = new FarmaceutaDAO();
            farmaceutaE = new Farmaceuta();

            
            farmaceutaE.setCedula(4545454l);
            farmaceutaE.setApellido("Motorola");
            farmaceutaE.setClave("clave123");
            farmaceutaE.setFechaNacimiento("1994/10/18");
            farmaceutaE.setNick("Usu12");
            farmaceutaE.setNombre("Moto G");
            farmaceutaE.setTarjetaProfesional("abc123def456");
            farmaceutaE.setTelefono(3156584217L);
            farmaceutaE.setTurnoFarmaceuta("6a9");

            farmaceutaE = farmaceutaD.insertar(farmaceutaE);

            if (farmaceutaE.getCodigoEmpleado() == null) {

            } else {
                System.out.println("Cedula: " + farmaceutaE.getCedula());
                System.out.println("Apellido: " + farmaceutaE.getApellido());
                System.out.println("Clave: " + farmaceutaE.getClave());
                System.out.println("fecha de Nacimiento: " + farmaceutaE.getFechaNacimiento());
                System.out.println("Nick: " + farmaceutaE.getNick());
                System.out.println("Nombre: " + farmaceutaE.getNombre());
                System.out.println("Tarjeta Profesional: " + farmaceutaE.getTarjetaProfesional());
                System.out.println("Telefono: " + farmaceutaE.getTelefono());
                System.out.println("Turno Farmaceuta: " + farmaceutaE.getTurnoFarmaceuta());
            }

        } catch (Exception e) {
            Logger.getLogger(FarmaceutaTest.class.getName()).log(Level.SEVERE, null, e);

        }
    }

}
